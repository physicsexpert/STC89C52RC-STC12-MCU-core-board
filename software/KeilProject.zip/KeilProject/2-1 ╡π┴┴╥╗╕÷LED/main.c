
#include <reg51.h>
#define uchar unsigned char
#define uint unsigned int
uchar code a[]={0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};//������λѡ�ѡ��ڼ������������
uchar code b[]={0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80};//��������ѡ�ѡ����Ӧλ����ʾʲô����
uchar code seg[]={0x88,0x83,0xC6,0xA1,0x86,0x8E};
uchar con=0;
void delayms(uchar ms)
{
 uchar i;
 while(ms--);
 for(i=0;i<123;i++);
}
void main(void)
{
 TMOD|=0x50;
 TH1=65532/256;
 TL1=65532%256;
 TR1=1;
 EA=1;
 ET1=1;
 while(1)
 {
  int i;
  for(i=0;i<8;i++)
  {
   P2=a[i];   
   P0=b[i];
   delayms(3);
  }
 }
}
void t1(void) interrupt 3
{
 TH1=65532/256;
 TL1=65532%256;
 while(1)
 {
  uchar i;
  for(i=0;i<6;i++)
  {
   P2=0x80;
   P0=0x83;
   delayms(1000);
   P0=0x86;
   delayms(1000);
  }
 }
}
id main()
{
	P2=0xFE;	//1111 1110
	while(1)
	{
		
	}
}