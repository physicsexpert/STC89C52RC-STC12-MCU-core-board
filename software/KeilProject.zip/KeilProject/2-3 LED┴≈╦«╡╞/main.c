#include <REGX52.H>
#define uchar unsigned char
#define uint unsigned int
unsigned char m;
unsigned char i,j,k,l,kp;
unsigned char const
ceshi[]= {0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f};
sbit K1=P3^1;  //��ʼ
sbit K3=P3^2;  //ʹ���ж�  ����
sbit K4=P3^3;  //ʹ���ж�  ��ͣ
void Int0Init()
{
    IT0=1;
    EX0=1;
	 IT1=1;
    EX1=1;
    EA=1;
}
void delayms(unsigned int ms)
{
    unsigned char i;
    while(ms--);
    for(i=0; i<123; i++);
}

uchar buttonscan(void)
{
    if(P3_1==0)
    {
        delayms(100);
        if(P3_1==0)
        {
            return 1;
        }

    }
    else
    {
        return 0;
    }
}


void display()
{
    P2=0x00;
    P0=ceshi[k];
    delayms(2);
    P2=0x04;
    P0=(ceshi[l]);
    delayms(2);
}

void main(void)
{

    k=0;
    l=0;

    TMOD = 0x10;

    TL1 = 0x00;
    TH1 = 0xEE;
    
    TR1 = 1;
    EA=1;
    ET1=1;
    Int0Init();

    while(1) {



        m=buttonscan();
        if(m==0)
        {


            P2=0x00;
            P0=ceshi[0];
            delayms(5);
            P2=0x04;
            P0=(ceshi[0]);
            delayms(5);

        }
        else if(m==1)
        {
            while(1)
            {
                display();
            }

        }
    }
}



void t1_int(void) interrupt 3
{
    TL1 = 0x00;
    TH1 = 0xEE;
    i+=1;
    if(i>199)


    {
        k+=1;
        if(k>9) k=0;
        i=0;
        j+=1;
        if(j>9)

        {
            l+=1;
            if(l>9) l=0;
            j=0;
        }

    }
}



//�жϷ�������������
void Int0()  interrupt 0
{
    delayms(100);
    if(K3==0)
    {
			i=0;
			j=0;
        k=0;
        l=0;
    }
}
//�жϷ�������������
void Int1()  interrupt 2
{
    delayms(100);
    if(K4==0)
    {
			switch(kp){ 
				case 0:TR1 = 0;ET1=0;kp=1;break;
				case 1:TR1 = 1;ET1=1;kp=0;break;
			}
			
    }
}

